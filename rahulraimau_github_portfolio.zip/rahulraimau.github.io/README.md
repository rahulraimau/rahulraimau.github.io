# Rahul Rai Portfolio
A personal data analytics portfolio showcasing projects in Power BI, Python, and SQL.